#ifndef TEST_H
#define TEST_H
#include "LinkedListOfInts.h"

using namespace std;

class Test
{
    private:
    
		LinkedListOfInts ls;
    
    public:
    	Test();
    	void test();
   
};
#endif
    
